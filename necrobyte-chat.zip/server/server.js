import express from 'express';
import cors from 'cors';
import { OpenAI } from 'openai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Enable CORS for frontend communication
app.use(cors());
app.use(express.json());

// Initialize OpenAI client for Hugging Face
// Make sure HF_TOKEN is set in your .env file
const client = new OpenAI({
  baseURL: "https://router.huggingface.co/v1",
  apiKey: process.env.HF_TOKEN, 
});

app.post('/api/chat', async (req, res) => {
  try {
    const { messages } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Invalid messages format' });
    }

    // Call the DeepSeek model
    const chatCompletion = await client.chat.completions.create({
      model: "deepseek-ai/DeepSeek-R1:novita", // Exact model requested
      messages: messages,
      max_tokens: 1024,
      temperature: 0.7,
    });

    const aiMessage = chatCompletion.choices[0].message.content;
    res.json({ message: aiMessage });

  } catch (error) {
    console.error('Error calling AI provider:', error);
    res.status(500).json({ 
      error: 'Failed to generate response', 
      details: error.message 
    });
  }
});

app.listen(port, () => {
  console.log(`Necrobyte AI Server running on http://localhost:${port}`);
  console.log('Ensure HF_TOKEN is set in your environment variables.');
});