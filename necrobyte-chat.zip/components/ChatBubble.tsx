import React from 'react';
import { Message } from '../types';

interface ChatBubbleProps {
  message: Message;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div 
        className={`
          max-w-[85%] sm:max-w-[75%] 
          p-4 sm:p-5 
          text-sm sm:text-base 
          font-medium 
          border-2 border-black 
          shadow-hard 
          whitespace-pre-wrap
          ${isUser 
            ? 'bg-necro-blue text-white rounded-tl-xl rounded-tr-xl rounded-bl-xl' 
            : 'bg-white text-black rounded-tr-xl rounded-tl-xl rounded-br-xl'
          }
        `}
      >
        {/* Avatar/Label */}
        <div className={`text-xs font-bold uppercase tracking-wider mb-1 ${isUser ? 'text-black opacity-60' : 'text-necro-purple'}`}>
          {isUser ? 'You' : 'Necrobyte AI'}
        </div>
        
        {/* Content */}
        <div className="leading-relaxed">
          {message.content}
        </div>
      </div>
    </div>
  );
};