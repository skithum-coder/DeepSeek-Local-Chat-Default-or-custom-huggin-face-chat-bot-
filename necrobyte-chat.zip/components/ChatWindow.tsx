import React, { useState, useEffect, useRef } from 'react';
import { ChatBubble } from './ChatBubble';
import { ChatInput } from './ChatInput';
import { Message } from '../types';
import { OpenAI } from 'openai';

export const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "SYSTEM: online.\nGreetings, student. I am the Necrobyte AI. Ask me for any Computer Science definition, code example, or explanation. Zero fluff guaranteed." }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [apiKey, setApiKey] = useState(localStorage.getItem('hf_token') || '');
  const [showKeyModal, setShowKeyModal] = useState(!apiKey);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const saveApiKey = (key: string) => {
    localStorage.setItem('hf_token', key);
    setApiKey(key);
    setShowKeyModal(false);
  };

  const handleSendMessage = async (content: string) => {
    if (!apiKey) {
      setShowKeyModal(true);
      return;
    }

    const userMessage: Message = { role: 'user', content };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // Direct client-side call to fix "Failed to fetch" backend issues in demo environment
      const client = new OpenAI({
        baseURL: "https://router.huggingface.co/v1",
        apiKey: apiKey,
        dangerouslyAllowBrowser: true 
      });

      const completion = await client.chat.completions.create({
        model: "deepseek-ai/DeepSeek-R1:novita",
        messages: [
          { role: "system", content: "You are Necrobyte AI, a strict, direct Computer Science tutor. Keep answers concise, technical, and use the 'Necrobyte' aesthetic (slightly edgy, cybernetic). Do not use markdown bolding too much. Focus on code blocks and raw definitions." },
          ...messages.map(m => ({ role: m.role, content: m.content })),
          { role: "user", content: content }
        ],
        max_tokens: 1024,
        temperature: 0.7,
      });

      const rawContent = completion.choices[0].message.content || "Error: Empty response.";
      
      // Clean <think> tags which are common in DeepSeek-R1 responses to hide internal reasoning
      const aiContent = rawContent.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      
      const aiMessage: Message = {
        role: 'assistant',
        content: aiContent
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error: any) {
      console.error(error);
      let errorMsg = "CONNECTION ERROR: Could not reach DeepSeek API.";
      
      if (error?.status === 401) {
        errorMsg = "AUTH ERROR: Invalid API Key. Please reset your token.";
        setShowKeyModal(true);
        localStorage.removeItem('hf_token');
        setApiKey('');
      } else if (error?.message) {
        errorMsg = `ERROR: ${error.message}`;
      }

      const errorMessage: Message = {
        role: 'assistant',
        content: errorMsg
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] bg-white relative">
        {/* API Key Modal */}
        {showKeyModal && (
          <div className="absolute inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-necro-yellow border-2 border-black shadow-hard p-6 max-w-md w-full relative">
               <div className="absolute -top-3 -left-3 bg-black text-white px-2 py-1 text-xs font-bold uppercase tracking-wider">
                  System Alert
               </div>
               <h2 className="font-heading font-bold text-2xl mb-2">Authorization Required</h2>
               <p className="text-sm font-medium mb-4 leading-tight">
                 To access the Necrobyte Neural Network, please input your Hugging Face Access Token.
               </p>
               <input 
                 type="password" 
                 placeholder="hf_..."
                 className="w-full border-2 border-black p-3 mb-4 focus:shadow-hard focus:outline-none transition-all font-mono text-sm"
                 onKeyDown={(e) => {
                   if (e.key === 'Enter') saveApiKey(e.currentTarget.value);
                 }}
               />
               <div className="flex justify-end gap-2">
                 <button 
                   className="px-4 py-2 border-2 border-black font-bold uppercase hover:bg-white transition-colors text-sm"
                   onClick={() => window.open('https://huggingface.co/settings/tokens', '_blank')}
                 >
                   Get Token
                 </button>
                 <button 
                   className="px-4 py-2 bg-black text-white border-2 border-black font-bold uppercase hover:bg-gray-800 transition-colors shadow-hard-sm text-sm"
                   onClick={(e) => {
                     const input = e.currentTarget.parentElement?.previousElementSibling as HTMLInputElement;
                     saveApiKey(input.value);
                   }}
                 >
                   Connect
                 </button>
               </div>
               <p className="text-[10px] mt-4 opacity-60 text-center">
                 Token is stored locally in your browser.
               </p>
            </div>
          </div>
        )}

        {/* Chat Header / Decor */}
        <div className="bg-necro-yellow border-b-2 border-black p-2 flex justify-between items-center px-4 shadow-sm z-10">
            <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-necro-black animate-pulse"></div>
                <span className="font-heading font-bold text-sm uppercase tracking-wider">Live Session</span>
            </div>
            <div className="flex gap-4">
              <button 
                  onClick={() => {
                    localStorage.removeItem('hf_token');
                    setApiKey('');
                    setShowKeyModal(true);
                  }}
                  className="text-xs font-bold hover:underline transition-colors uppercase"
              >
                  Reset Key
              </button>
              <button 
                  onClick={() => setMessages([{ role: 'assistant', content: "SYSTEM: reset.\nReady for new queries." }])}
                  className="text-xs font-bold underline hover:text-white transition-colors uppercase"
              >
                  Clear Terminal
              </button>
            </div>
        </div>

        {/* Messages Area */}
        <div className="flex-grow overflow-y-auto p-4 sm:p-6 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]">
            <div className="max-w-4xl mx-auto pb-4">
            {messages.map((msg, index) => (
                <ChatBubble key={index} message={msg} />
            ))}
            
            {/* Loading Indicator */}
            {isLoading && (
                <div className="flex w-full justify-start mb-6">
                 <div className="bg-white border-2 border-black p-4 rounded-tr-xl rounded-tl-xl rounded-br-xl shadow-hard flex items-center gap-2">
                    <span className="text-xs font-bold mr-2">THINKING</span>
                    <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-necro-black rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-necro-black rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-2 h-2 bg-necro-black rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                 </div>
                </div>
            )}
            <div ref={messagesEndRef} />
            </div>
        </div>

        {/* Input Area */}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};