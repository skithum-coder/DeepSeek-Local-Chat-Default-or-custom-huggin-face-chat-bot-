import React, { useState, KeyboardEvent, useRef, useEffect } from 'react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (input.trim() && !isLoading) {
      onSendMessage(input.trim());
      setInput('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto'; // Reset height
      }
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const adjustHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  };

  useEffect(() => {
    adjustHeight();
  }, [input]);

  return (
    <div className="border-t-2 border-black bg-necro-gray p-4 sm:p-6 sticky bottom-0 w-full z-20">
      <div className="max-w-4xl mx-auto flex gap-3 items-end">
        <div className="relative flex-grow">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              placeholder="Ask for a definition (e.g., 'What is Recursion?')"
              className="w-full bg-white border-2 border-black p-3 pr-10 shadow-hard-sm focus:shadow-hard focus:outline-none focus:translate-x-[-1px] focus:translate-y-[-1px] transition-all resize-none overflow-hidden min-h-[50px] font-sans text-base"
              rows={1}
            />
        </div>
        
        <button
          onClick={handleSend}
          disabled={isLoading || !input.trim()}
          className={`
            btn-fill h-[50px] px-6 flex items-center justify-center
            border-2 border-black font-heading font-bold uppercase tracking-wider
            shadow-hard-sm hover:shadow-hard transition-all
            ${isLoading ? 'bg-gray-400 cursor-not-allowed text-gray-700' : 'bg-necro-yellow text-black cursor-pointer'}
          `}
        >
          {isLoading ? (
            <i className="fas fa-spinner fa-spin"></i>
          ) : (
            <i className="fas fa-paper-plane"></i>
          )}
        </button>
      </div>
      <div className="max-w-4xl mx-auto text-center mt-2">
         <p className="text-[10px] uppercase font-bold text-gray-500">Powered by DeepSeek-R1 • AI can make mistakes</p>
      </div>
    </div>
  );
};